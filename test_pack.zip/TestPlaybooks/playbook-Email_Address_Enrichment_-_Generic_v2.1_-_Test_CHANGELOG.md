## [Unreleased]


## [20.5.2] - 2020-05-26
#### New Playbook
A test for email address enrichment. Currently, due to issues, the test does not check all domain squatting results or whether the email addresses were detected as internal or external.