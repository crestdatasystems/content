## [Unreleased]


## [20.5.2] - 2020-05-26
#### New Playbook
A test playbook for extracting indicators from a file.
Supported file types:
PDF
TXT
HTM, HTML
DOC, DOCX
RTF
XLSX
PPTX
XML