## [Unreleased]


## [20.5.2] - 2020-05-26
#### New Playbook
A test for the Endpoint Enrichment - Generic playbook.
We use specific hostnames that are known on the current integrations. The following list defines the integrations and the hostnames that should be enriched using them:
Active Directory - moshe
ePO - WIN-AQ0LQQOG4Q7

These should work but are not currently tested:
Carbon Black Enterprise Response - WIN-B73RGE9AAIF
CrowdStrike Falcon Host - AUTOMATIONPC
Cylance Protect v2 - DESKTOP-M7E991U