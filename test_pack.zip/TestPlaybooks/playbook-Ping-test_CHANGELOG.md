## [Unreleased]


## [20.5.2] - 2020-05-26
#### New Playbook
Test Ping command with various scenarios